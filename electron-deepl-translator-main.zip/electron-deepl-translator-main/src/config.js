const config = {
  url: "https://www.deepl.com/translator"
};

module.exports = config;