# electron-pearson
load page https://www.deepl.com/translator
![](readme_files/1.jpg)
